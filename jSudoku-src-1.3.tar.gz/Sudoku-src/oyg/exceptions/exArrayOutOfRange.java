package oyg.exceptions;

public class exArrayOutOfRange extends Exception{}


